# 🤖 Parlament Bot

Telegram-бот на **Java 21 + Spring Boot 3**, развёрнутый на **Railway.app**.

---

## 📋 Содержание

- [Стек технологий](#стек-технологий)
- [Переменные окружения](#переменные-окружения)
- [Локальный запуск](#локальный-запуск)
- [Деплой на Railway](#деплой-на-railway)
- [Режимы работы бота](#режимы-работы-бота)
- [Структура проекта](#структура-проекта)

---

## Стек технологий

| Компонент | Версия |
|---|---|
| Java | 21 (Eclipse Temurin) |
| Spring Boot | 3.3.5 |
| Telegram Bots API | 6.9.0 |
| Maven | 3.9+ |
| Deploy | Railway.app (Docker) |

---

## Переменные окружения

| Переменная | Обязательная | Описание | Пример |
|---|---|---|---|
| `BOT_TOKEN` | ✅ | Токен от [@BotFather](https://t.me/BotFather) | `123456:ABC-DEF...` |
| `BOT_USERNAME` | ✅ | Username бота без `@` | `MyParlamentBot` |
| `BOT_MODE` | ❌ | Режим работы: `long_polling` или `webhook` | `long_polling` |
| `BOT_WEBHOOK_ENABLED` | ❌ | Включить webhook (true/false) | `false` |
| `BOT_WEBHOOK_PUBLIC_URL` | ❌* | Публичный URL для webhook | `https://xxx.up.railway.app` |
| `BOT_WEBHOOK_PATH` | ❌ | Путь webhook-endpoint | `/telegram/webhook` |
| `BOT_WEBHOOK_SECRET_TOKEN` | ❌ | Секретный токен для валидации заголовков | `my-secret` |
| `PORT` | ❌ | HTTP порт (Railway подставляет автоматически) | `8080` |

> ⚠️ `BOT_WEBHOOK_PUBLIC_URL` обязателен если `BOT_MODE=webhook` или `BOT_WEBHOOK_ENABLED=true`

---

## Локальный запуск

### Требования

- Java 21+
- Maven 3.9+

### 1. Клонировать репозиторий

```bash
git clone https://github.com/Ahmadjon-Anarkulov/Parlament.git
cd Parlament
```

### 2. Установить переменные окружения

```bash
# Linux / macOS
export BOT_TOKEN="ваш_токен_от_botfather"
export BOT_USERNAME="ваш_username_бота"

# Windows (PowerShell)
$env:BOT_TOKEN="ваш_токен_от_botfather"
$env:BOT_USERNAME="ваш_username_бота"
```

Либо создайте файл `src/main/resources/application-local.yml`:

```yaml
bot:
  token: "ваш_токен"
  username: "ваш_username"
```

И запускайте с профилем: `mvn spring-boot:run -Dspring-boot.run.profiles=local`

### 3. Собрать и запустить

```bash
# Сборка
mvn clean package -DskipTests

# Запуск
java -jar target/parlament-bot-1.0.0.jar
```

Или одной командой через Maven:

```bash
mvn spring-boot:run
```

### 4. Проверить работоспособность

```bash
curl http://localhost:8080/actuator/health
# Ожидаемый ответ: {"status":"UP"}
```

---

## Деплой на Railway

### Способ 1: Из GitHub (рекомендуется)

1. Зайдите на [railway.app](https://railway.app) и создайте новый проект
2. Выберите **"Deploy from GitHub repo"**
3. Подключите репозиторий `Ahmadjon-Anarkulov/Parlament`
4. Railway автоматически обнаружит `railway.toml` и `Dockerfile`

### Способ 2: Railway CLI

```bash
# Установить CLI
npm install -g @railway/cli

# Войти в аккаунт
railway login

# Инициализировать проект
railway init

# Задеплоить
railway up
```

### Настройка переменных на Railway

В дашборде Railway:

1. Откройте ваш сервис → вкладка **Variables**
2. Добавьте следующие переменные:

```
BOT_TOKEN        = ваш_токен_от_botfather
BOT_USERNAME     = ваш_username_бота
BOT_MODE         = long_polling
```

Или используйте Railway CLI:

```bash
railway variables set BOT_TOKEN="ваш_токен"
railway variables set BOT_USERNAME="ваш_username"
railway variables set BOT_MODE="long_polling"
```

### Настройка для Webhook режима (опционально)

Webhook более эффективен для продакшена. После деплоя Railway даст вам публичный URL вида `https://xxx.up.railway.app`.

Добавьте переменные:

```
BOT_MODE                 = webhook
BOT_WEBHOOK_ENABLED      = true
BOT_WEBHOOK_PUBLIC_URL   = https://xxx.up.railway.app
BOT_WEBHOOK_PATH         = /telegram/webhook
```

---

## Режимы работы бота

| Режим | Когда использовать |
|---|---|
| `long_polling` | Разработка, тестирование, простой деплой |
| `webhook` | Продакшен, высокая нагрузка, экономия ресурсов |

---

## Структура проекта

```
src/main/java/com/parlament/
├── ParlamentBotApplication.java     # Точка входа (main class)
├── config/
│   ├── BotProperties.java           # Конфигурационные свойства бота
│   └── TelegramConfig.java          # Регистрация бота (long polling / webhook)
├── telegram/
│   ├── LongPollingParlamentBot.java  # Long polling реализация
│   ├── TelegramSenderClient.java     # HTTP клиент для Telegram API
│   ├── TelegramBotSender.java        # Интерфейс отправки сообщений
│   ├── UpdateProcessor.java          # Диспетчер входящих update
│   └── UpdateValidator.java          # Валидация входящих запросов
├── handler/
│   ├── CommandHandler.java           # Обработка команд (/start и т.д.)
│   ├── TextHandler.java              # Обработка текстовых сообщений
│   └── CallbackHandler.java          # Обработка callback query
├── service/
│   ├── CartService.java              # Логика корзины
│   ├── OrderService.java             # Логика заказов
│   └── SessionService.java           # Управление сессиями пользователей
├── model/                            # Модели данных
├── data/
│   └── ProductCatalog.java           # Каталог товаров (in-memory)
├── repository/                       # Репозитории
├── controller/
│   └── TelegramWebhookController.java # Webhook endpoint
├── exception/                        # Обработка ошибок
└── util/                             # Утилиты (клавиатуры, форматирование)
```

---

## Health Check

Spring Boot Actuator доступен по адресу:

- `GET /actuator/health` — статус приложения
- `GET /actuator/info` — информация о сборке
- `GET /actuator/metrics` — метрики

---

## Логирование

Логи настроены через `logback-spring.xml`. В продакшене Railway собирает логи автоматически через вкладку **Logs** в дашборде.

---

## Лицензия

MIT
